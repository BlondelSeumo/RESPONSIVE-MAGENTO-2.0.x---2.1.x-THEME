<?php
/**
 * Copyright © 2015 PlazaThemes.com. All rights reserved.

 * @author PlazaThemes Team <contact@plazathemes.com>
 */

namespace Plazathemes\Blog\Controller\Adminhtml\Post;

/**
 * Blog post edit controller
 */
class Edit extends \Plazathemes\Blog\Controller\Adminhtml\Post
{

}
