<?php
/**
 * Copyright © 2015 PlazaThemes.com. All rights reserved.

 * @author PlazaThemes Team <contact@plazathemes.com>
 */

namespace Plazathemes\Blog\Controller\Adminhtml\Category;

/**
 * Blog category create new controller
 */
class NewAction extends \Plazathemes\Blog\Controller\Adminhtml\Category
{

}
