<?php
/**
 * Copyright © 2015 PlazaThemes.com. All rights reserved.

 * @author PlazaThemes Team <contact@plazathemes.com>
 */

namespace Plazathemes\Blog\Controller\Adminhtml\Post;

/**
 * Blog post related products grid controller
 */
class RelatedProductsGrid extends RelatedProducts
{

}
