<?php
/**
 * Copyright © 2015 SW-THEMES. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Plazathemes_Layout',
    __DIR__
);
